<?php
/**
 * Created by PhpStorm.
 * User: hmx
 * Date: 2018/10/16
 * Time: 14:09
 */

namespace app\admin\controller;


class Error
{
     public function index()
     {
         return '<<<<<----!!!!系统更新升级中!!!!---->>>>';
     }

}