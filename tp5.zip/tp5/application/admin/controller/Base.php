<?php
/**
 * Created by PhpStorm.
 * User: hmx
 * Date: 2018/10/16
 * Time: 14:11
 */

namespace app\admin\controller;


use think\Controller;

class Base extends Controller
{
}